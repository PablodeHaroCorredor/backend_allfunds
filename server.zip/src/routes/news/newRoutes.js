const express = require('express');
const New = require('../../models/New');
const jwt = require('jsonwebtoken');
const router = express.Router();

// Middleware de autenticación
function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) return res.sendStatus(403);

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    console.log(req.user); // Verifica el contenido del token decodificado
    next();
  });
}


// Middleware de rol
function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.sendStatus(403);
  next();
}

// Obtener todas las noticias
router.get('/', async (req, res) => {
  const news = await New.find().sort({ date: -1 });
  res.json(news);
});

// Agregar noticia (solo admin)
router.post('/', async (req, res) => {
  try {
    // Crea una nueva instancia de New con archivedDate siempre como null
    const newNews = new New({
      ...req.body,
      archiveDate: null // Fuerza archivedDate a null
    });

    await newNews.save();
    res.json(newNews);
  } catch (error) {
    console.error('Error al crear la noticia:', error);
    res.status(500).json({ message: 'Error al crear la noticia' });
  }
});

// Archivar noticia
router.put('/:id/archive', async (req, res) => {
  const news = await New.findByIdAndUpdate(req.params.id, { archiveDate: new Date() });
  res.json(news);
});

router.get('/active', async (req, res) => {
  try {
    // Filtra las noticias que no tienen una fecha en archivedDate
    const activeNews = await New.find({ archiveDate:null }).sort({ date: -1 });
    res.json(activeNews); // Devuelve las noticias activas en formato JSON
  } catch (error) {
    console.error('Error al obtener las noticias activas:', error);
    res.status(500).json({ message: 'Error al obtener las noticias activas' });
  }
});


// Endpoint para obtener todas las noticias archivadas
router.get('/archived', async (req, res) => {
  try {
    // Filtra las noticias que tienen una fecha en archivedDate
    const archivedNews = await New.find({ archiveDate: { $ne: null } }).sort({ date: -1 });
    res.json(archivedNews); // Devuelve las noticias archivadas en formato JSON
  } catch (error) {
    console.error('Error al obtener las noticias archivadas:', error);
    res.status(500).json({ message: 'Error al obtener las noticias archivadas' });
  }
});


// Eliminar noticia
router.delete('/:id', async (req, res) => {
  await New.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted Archived new' });
});


router.put('/edit/:id', async (req, res) => {
  const { id } = req.params;
  const updateData = req.body;

  try {
    const updatedNews = await News.findByIdAndUpdate(id, updateData, { new: true });
    if (!updatedNews) {
      return res.status(404).json({ message: 'Noticia no encontrada' });
    }
    res.json(updatedNews);
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar la noticia', error });
  }
});

module.exports = router;
